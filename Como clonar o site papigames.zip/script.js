// DOM Elements
const cookieNotice = document.querySelector('.cookie-notice');
const acceptCookieBtn = cookieNotice.querySelector('.btn');
const backToTopBtn = document.getElementById('backToTopBtn-button');
const form = document.querySelector('.signup-right-content-form');
const inputs = form.querySelectorAll('input');

// Cookie Notice Functionality
acceptCookieBtn.addEventListener('click', () => {
    cookieNotice.style.display = 'none';
    localStorage.setItem('cookiesAccepted', 'true');
});

// Check if cookies were already accepted
if (localStorage.getItem('cookiesAccepted') === 'true') {
    cookieNotice.style.display = 'none';
}

// Back to Top Functionality
backToTopBtn.addEventListener('click', () => {
    window.scrollTo({
        top: 0,
        behavior: 'smooth'
    });
});

// Show/Hide Back to Top Button
window.addEventListener('scroll', () => {
    if (window.scrollY > 300) {
        backToTopBtn.style.opacity = '1';
        backToTopBtn.style.pointerEvents = 'auto';
    } else {
        backToTopBtn.style.opacity = '0.5';
        backToTopBtn.style.pointerEvents = 'none';
    }
});

// Form Validation
function validateEmail(email) {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return emailRegex.test(email);
}

function validateCPF(cpf) {
    // Remove non-numeric characters
    cpf = cpf.replace(/\D/g, '');
    
    // Check if CPF has 11 digits
    if (cpf.length !== 11) return false;
    
    // Check if all digits are the same
    if (/^(\d)\1{10}$/.test(cpf)) return false;
    
    // Validate CPF algorithm
    let sum = 0;
    for (let i = 0; i < 9; i++) {
        sum += parseInt(cpf.charAt(i)) * (10 - i);
    }
    let remainder = (sum * 10) % 11;
    if (remainder === 10 || remainder === 11) remainder = 0;
    if (remainder !== parseInt(cpf.charAt(9))) return false;
    
    sum = 0;
    for (let i = 0; i < 10; i++) {
        sum += parseInt(cpf.charAt(i)) * (11 - i);
    }
    remainder = (sum * 10) % 11;
    if (remainder === 10 || remainder === 11) remainder = 0;
    if (remainder !== parseInt(cpf.charAt(10))) return false;
    
    return true;
}

function validatePhone(phone) {
    // Remove non-numeric characters
    phone = phone.replace(/\D/g, '');
    
    // Check if phone has 10 or 11 digits
    return phone.length === 10 || phone.length === 11;
}

// Input Formatting
const cpfInput = document.getElementById('cpf');
const phoneInput = document.getElementById('phone');

cpfInput.addEventListener('input', (e) => {
    let value = e.target.value.replace(/\D/g, '');
    value = value.replace(/(\d{3})(\d)/, '$1.$2');
    value = value.replace(/(\d{3})(\d)/, '$1.$2');
    value = value.replace(/(\d{3})(\d{1,2})$/, '$1-$2');
    e.target.value = value;
});

phoneInput.addEventListener('input', (e) => {
    let value = e.target.value.replace(/\D/g, '');
    if (value.length <= 10) {
        value = value.replace(/(\d{2})(\d)/, '($1) $2');
        value = value.replace(/(\d{4})(\d)/, '$1-$2');
    } else {
        value = value.replace(/(\d{2})(\d)/, '($1) $2');
        value = value.replace(/(\d{5})(\d)/, '$1-$2');
    }
    e.target.value = value;
});

// Form Submission
const submitBtn = form.querySelector('.primary-filled-btn');
submitBtn.addEventListener('click', (e) => {
    e.preventDefault();
    
    const formData = {
        email: document.getElementById('email').value,
        cpf: document.getElementById('cpf').value,
        password: document.getElementById('password').value,
        confirmPassword: document.getElementById('confirm_password').value,
        phone: document.getElementById('phone').value,
        birthDate: document.getElementById('birth_date').value,
        promoCode: document.getElementById('promo_code').value
    };
    
    // Validation
    const errors = [];
    
    if (!formData.email) {
        errors.push('E-mail é obrigatório');
    } else if (!validateEmail(formData.email)) {
        errors.push('E-mail inválido');
    }
    
    if (!formData.cpf) {
        errors.push('CPF é obrigatório');
    } else if (!validateCPF(formData.cpf)) {
        errors.push('CPF inválido');
    }
    
    if (!formData.password) {
        errors.push('Senha é obrigatória');
    } else if (formData.password.length < 6) {
        errors.push('Senha deve ter pelo menos 6 caracteres');
    }
    
    if (formData.password !== formData.confirmPassword) {
        errors.push('Senhas não coincidem');
    }
    
    if (!formData.phone) {
        errors.push('Telefone é obrigatório');
    } else if (!validatePhone(formData.phone)) {
        errors.push('Telefone inválido');
    }
    
    if (!formData.birthDate) {
        errors.push('Data de nascimento é obrigatória');
    } else {
        const birthDate = new Date(formData.birthDate);
        const today = new Date();
        const age = today.getFullYear() - birthDate.getFullYear();
        if (age < 18) {
            errors.push('Você deve ter pelo menos 18 anos');
        }
    }
    
    if (errors.length > 0) {
        alert('Erros encontrados:\n' + errors.join('\n'));
        return;
    }
    
    // If validation passes, show success message
    alert('Formulário válido! Próximo passo seria enviar os dados para o servidor.');
    console.log('Form data:', formData);
});

// Input Focus Effects
inputs.forEach(input => {
    input.addEventListener('focus', () => {
        input.parentElement.classList.add('focused');
    });
    
    input.addEventListener('blur', () => {
        input.parentElement.classList.remove('focused');
    });
});

// Smooth Scrolling for Navigation Links
document.querySelectorAll('a[href^="#"]').forEach(anchor => {
    anchor.addEventListener('click', function (e) {
        e.preventDefault();
        const target = document.querySelector(this.getAttribute('href'));
        if (target) {
            target.scrollIntoView({
                behavior: 'smooth'
            });
        }
    });
});

// Language Selector (Mock functionality)
const langSelector = document.querySelector('.lang-selector');
langSelector.addEventListener('click', () => {
    alert('Seletor de idioma - funcionalidade seria implementada aqui');
});

// Initialize
document.addEventListener('DOMContentLoaded', () => {
    console.log('Papi Games Clone - Loaded successfully');
    
    // Set initial back to top button state
    backToTopBtn.style.opacity = '0.5';
    backToTopBtn.style.pointerEvents = 'none';
});

